<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class UCU_Collegium_Admin_Settings {
    public static function render(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'ucu-collegium-booking' ) );
        }
        include UCU_COLLEGIUM_BOOKING_PATH . 'admin/views/settings.php';
    }
}
